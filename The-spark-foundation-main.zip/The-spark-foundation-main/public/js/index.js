// console.log("JS is working!");
// const sr = ScrollReveal({
//     origin: "bottom",
//     distance: "80px",
//     duration: 1000,
//     reset: true,
//   });


//   sr.reveal(".container");
//   sr.reveal(".card");


